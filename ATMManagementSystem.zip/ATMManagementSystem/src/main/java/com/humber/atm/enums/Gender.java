package com.humber.atm.enums;

public enum Gender {

	MALE,
    FEMALE,
    NOT_SPECIFIED
}
